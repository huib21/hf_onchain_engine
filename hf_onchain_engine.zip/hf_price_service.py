
# hf_price_service.py
#
# High-frequency price service:
# - draait 24/7 op een (Runpod) CPU
# - gebruikt PriceRouter (Raydium on-chain + Jupiter fallback)
# - meet volatility per base/quote pair
#
# Gebruik:
#   1) Vul HELIUS_API_KEY in in price_engine/config.py
#   2) (optioneel) pas DEFAULT_TOKENS e.d. aan in config.py
#   3) pip install requests
#   4) python hf_price_service.py

import time
import logging
from collections import deque
from typing import Dict, Tuple, Deque, Optional

from price_engine import PriceRouter
from price_engine.config import (
    DEFAULT_TOKENS,
    DEFAULT_QUOTE_TOKEN,
    DEFAULT_POLL_INTERVAL_SEC,
    DEFAULT_VOL_WINDOW_SEC,
    DEFAULT_VOL_THRESHOLD_PCT,
)


class VolatilityTracker:
    """Sliding-window volatility tracker per symbol."""

    def __init__(self, window_sec: float):
        self.window_sec = window_sec
        # symbol -> deque[(timestamp, price)]
        self.history: Dict[str, Deque[Tuple[float, float]]] = {}

    def update(self, symbol: str, ts: float, price: float) -> Optional[float]:
        dq = self.history.setdefault(symbol, deque())
        dq.append((ts, price))

        cutoff = ts - self.window_sec
        while dq and dq[0][0] < cutoff:
            dq.popleft()

        if len(dq) < 2:
            return None

        first_ts, first_price = dq[0]
        if first_price == 0:
            return None

        pct_change = (price - first_price) / first_price * 100.0
        return pct_change


class HFPriceService:
    def __init__(
        self,
        tokens=None,
        quote_token: str = DEFAULT_QUOTE_TOKEN,
        poll_interval_sec: float = DEFAULT_POLL_INTERVAL_SEC,
        vol_window_sec: float = DEFAULT_VOL_WINDOW_SEC,
        vol_threshold_pct: float = DEFAULT_VOL_THRESHOLD_PCT,
    ):
        self.router = PriceRouter()
        self.tokens = tokens or list(DEFAULT_TOKENS)
        self.quote = quote_token
        self.poll_interval_sec = poll_interval_sec
        self.vol_window_sec = vol_window_sec
        self.vol_threshold_pct = vol_threshold_pct
        self.vol_tracker = VolatilityTracker(self.vol_window_sec)

    def on_volatility_event(
        self, symbol: str, last_price: float, pct_move: float
    ) -> None:
        """Hook voor grote prijsbewegingen.

        HIER hang je later je GPU-strategie / executor aan.
        """
        logging.warning(
            f"[VOL] {symbol}/{self.quote} move = {pct_move:+.3f}% | last={last_price:.8f} {self.quote}"
        )
        # TODO:
        # - stuur event naar GPU-service (ZeroMQ/Redis/HTTP)
        # - of schrijf naar message queue / Kafka / PubSub
        # - of stuur Telegram notificatie

    def run_forever(self) -> None:
        logging.info("HFPriceService gestart.")
        logging.info(
            f"Tokens: {self.tokens}, Quote: {self.quote}, "
            f"Poll={self.poll_interval_sec}s, "
            f"Window={self.vol_window_sec}s, Threshold={self.vol_threshold_pct}%"
        )

        while True:
            loop_start = time.time()

            for base in self.tokens:
                if base.upper() == self.quote.upper():
                    continue

                price = self.router.get_price(base, self.quote)
                now = time.time()

                if price is None:
                    logging.info(f"{base}/{self.quote}: geen prijs")
                    continue

                pct_move = self.vol_tracker.update(base.upper(), now, price)

                if pct_move is None:
                    logging.info(
                        f"{base}/{self.quote}: price={price:.8f} (warming up window)"
                    )
                else:
                    logging.info(
                        f"{base}/{self.quote}: price={price:.8f}, "
                        f"Δ{int(self.vol_window_sec)}s={pct_move:+.3f}%"
                    )
                    if abs(pct_move) >= self.vol_threshold_pct:
                        self.on_volatility_event(base.upper(), price, pct_move)

            elapsed = time.time() - loop_start
            sleep_time = max(0.0, self.poll_interval_sec - elapsed)
            time.sleep(sleep_time)


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )
    service = HFPriceService()
    service.run_forever()


if __name__ == "__main__":
    main()
