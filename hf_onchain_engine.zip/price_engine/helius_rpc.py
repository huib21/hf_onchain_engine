
# helius_rpc.py

import requests
from typing import Any, Dict, List, Optional
from .config import HELIUS_API_KEY


class HeliusRPC:
    """Dunne JSON-RPC client voor Helius.

    Alleen de calls die we voor on-chain prijzen nodig hebben:
    - getTokenAccountBalance
    - getAccountInfo (optioneel voor toekomstige uitbreidingen)
    """

    def __init__(self, api_key: Optional[str] = None, timeout: float = 5.0):
        self.api_key = api_key or HELIUS_API_KEY
        self.url = f"https://mainnet.helius-rpc.com/?api-key={self.api_key}"
        self.timeout = timeout

    def _call(self, method: str, params: List[Any]) -> Any:
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": params,
        }
        resp = requests.post(self.url, json=payload, timeout=self.timeout)
        resp.raise_for_status()
        data = resp.json()
        if "error" in data:
            raise RuntimeError(f"Helius RPC error: {data['error']}")
        return data.get("result")

    def get_token_account_balance(self, token_account: str) -> float:
        """Return uiAmount van een SPL token account."""
        result = self._call("getTokenAccountBalance", [token_account])
        return float(result["value"]["uiAmount"])

    def get_account_info(self, pubkey: str, encoding: str = "base64") -> Dict[str, Any]:
        return self._call("getAccountInfo", [pubkey, {"encoding": encoding}])
