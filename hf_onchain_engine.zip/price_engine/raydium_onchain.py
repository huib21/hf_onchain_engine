
# raydium_onchain.py
#
# On-chain Raydium prijsengine:
# - Laadt Raydium token + liquidity JSON 1x in memory
# - Matcht (base, quote) symbols naar mints en pool
# - Vraagt Helius om token vault balances
# - Berekent prijs = quote_amount / base_amount (of omgekeerd als nodig)

import requests
from typing import Dict, List, Optional, Tuple

from .config import (
    RAYDIUM_TOKEN_LIST_URL,
    RAYDIUM_LIQUIDITY_URL,
)
from .helius_rpc import HeliusRPC


class RaydiumMetadata:
    """Houdt Raydium token & pool metadata in memory."""

    def __init__(self):
        self.symbol_to_mint: Dict[str, str] = {}
        # (base_mint, quote_mint) -> pool info dict
        self.pool_by_mints: Dict[Tuple[str, str], Dict] = {}

    def load(self) -> None:
        # 1) Token list ophalen
        token_resp = requests.get(RAYDIUM_TOKEN_LIST_URL, timeout=5.0)
        token_resp.raise_for_status()
        token_data = token_resp.json()

        # Raydium formaat: { "official": [...], "unOfficial": [...] }
        all_tokens: List[Dict] = []
        if isinstance(token_data, dict):
            for key in ("official", "unOfficial"):
                arr = token_data.get(key) or []
                all_tokens.extend(arr)

        for t in all_tokens:
            symbol = str(t.get("symbol", "")).upper()
            mint = str(t.get("mint", "")).strip()
            if symbol and mint and symbol not in self.symbol_to_mint:
                self.symbol_to_mint[symbol] = mint

        # 2) Liquidity list ophalen
        liq_resp = requests.get(RAYDIUM_LIQUIDITY_URL, timeout=5.0)
        liq_resp.raise_for_status()
        liq_data = liq_resp.json()

        all_pools: List[Dict] = []
        if isinstance(liq_data, dict):
            for key in ("official", "unOfficial"):
                arr = liq_data.get(key) or []
                all_pools.extend(arr)

        for pool in all_pools:
            base_mint = str(pool.get("baseMint", "")).strip()
            quote_mint = str(pool.get("quoteMint", "")).strip()
            if not base_mint or not quote_mint:
                continue
            key = (base_mint, quote_mint)
            # eerste tegengekomen pool wint; voor HF kun je later logica toevoegen
            if key not in self.pool_by_mints:
                self.pool_by_mints[key] = pool


class RaydiumOnchainPriceEngine:
    """On-chain prijzen via Raydium pools + Helius RPC.

    Let op: deze implementatie gebruikt een vereenvoudigde prijs:
      price(base/quote) = vault_quote / vault_base
    waarbij vault_* uit Raydium JSON komt en balances via Helius worden opgehaald.
    Voor HFT / MEV kun je later OpenBook orders en PnL meewegen.
    """

    def __init__(self, helius: Optional[HeliusRPC] = None):
        self.helius = helius or HeliusRPC()
        self.meta = RaydiumMetadata()
        self._loaded = False

    def ensure_loaded(self) -> None:
        if not self._loaded:
            self.meta.load()
            self._loaded = True

    def _get_mint(self, symbol: str) -> Optional[str]:
        self.ensure_loaded()
        return self.meta.symbol_to_mint.get(symbol.upper())

    def get_price(self, base_symbol: str, quote_symbol: str) -> Optional[float]:
        """Return price base/quote op basis van vault balances.

        Geeft None als:
          - geen pool gevonden
          - of balances niet beschikbaar
        """
        self.ensure_loaded()

        b_sym = base_symbol.upper()
        q_sym = quote_symbol.upper()

        base_mint = self._get_mint(b_sym)
        quote_mint = self._get_mint(q_sym)

        if not base_mint or not quote_mint:
            return None

        # Probeer pool in (base, quote) richting
        pool = self.meta.pool_by_mints.get((base_mint, quote_mint))
        reverse = False

        if pool is None:
            # Probeer omgekeerde richting
            pool = self.meta.pool_by_mints.get((quote_mint, base_mint))
            reverse = True

        if pool is None:
            return None

        base_vault = pool.get("baseVault")
        quote_vault = pool.get("quoteVault")
        if not base_vault or not quote_vault:
            return None

        try:
            base_amount = self.helius.get_token_account_balance(base_vault)
            quote_amount = self.helius.get_token_account_balance(quote_vault)
        except Exception:
            return None

        if base_amount <= 0 or quote_amount <= 0:
            return None

        # Als pool in omgekeerde richting is gevonden, draaien we de ratio om
        if not reverse:
            price = quote_amount / base_amount
        else:
            price = base_amount / quote_amount

        return float(price)
