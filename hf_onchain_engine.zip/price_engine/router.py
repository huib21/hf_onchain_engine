
# router.py

from typing import Optional, List, Dict

from .config import DEFAULT_TOKENS, DEFAULT_QUOTE_TOKEN
from .helius_rpc import HeliusRPC
from .jupiter_price import JupiterPriceClient
from .raydium_onchain import RaydiumOnchainPriceEngine


class PriceRouter:
    """Combineert meerdere price sources in een nette interface.

    Strategie:
      1. Raydium on-chain via Helius (supersnel, echte on-chain staat)
      2. Fallback: Jupiter price aggregator (altijd een prijs, zeer liquide)
    """

    def __init__(self):
        self.helius = HeliusRPC()
        self.raydium = RaydiumOnchainPriceEngine(self.helius)
        self.jupiter = JupiterPriceClient()

    @property
    def default_tokens(self) -> List[str]:
        return list(DEFAULT_TOKENS)

    @property
    def default_quote(self) -> str:
        return DEFAULT_QUOTE_TOKEN

    def get_price(self, base: str, quote: Optional[str] = None) -> Optional[float]:
        quote = quote or self.default_quote

        # 1. Probeer Raydium on-chain
        try:
            p = self.raydium.get_price(base, quote)
            if p is not None:
                return p
        except Exception as e:
            print(f"[router] Raydium price error {base}/{quote}: {e}")

        # 2. Fallback naar Jupiter
        try:
            prices_usd = self.jupiter.fetch_prices_usd([base, quote])
            return self.jupiter.get_pair_price(base, quote, prices_usd)
        except Exception as e:
            print(f"[router] Jupiter price error {base}/{quote}: {e}")
            return None

    def get_multi(self, pairs: List[Dict[str, str]]) -> Dict[str, Optional[float]]:
        """Vraag meerdere paren tegelijk op.

        pairs: [{"base": "SOL", "quote": "USDC"}, ...]
        ret:   {"SOL/USDC": 123.45, ...}
        """
        out: Dict[str, Optional[float]] = {}
        for p in pairs:
            base = p.get("base")
            quote = p.get("quote") or self.default_quote
            if not base:
                continue
            key = f"{base.upper()}/{quote.upper()}"
            out[key] = self.get_price(base, quote)
        return out
