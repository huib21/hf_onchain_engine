
# config.py
# Vul hier je eigen Helius API key in.
# LET OP: dit is hardcoded in de code; gebruik dit alleen op een vertrouwde server.

HELIUS_API_KEY = "PASTE_YOUR_HELIUS_API_KEY_HERE"

# Jupiter price endpoint (aggregated, on-chain based)
JUPITER_PRICE_URL = "https://price.jup.ag/v6/price"

# Raydium SDK endpoints (token + liquidity metadata)
RAYDIUM_TOKEN_LIST_URL = "https://api.raydium.io/v2/sdk/token/solana.mainnet.json"
RAYDIUM_LIQUIDITY_URL = "https://api.raydium.io/v2/sdk/liquidity/mainnet.json"

# Default tokenset voor jullie HF project
# Deze symbols worden gebruikt door de price-service
DEFAULT_TOKENS = [
    "SOL",
    "USDC",
    "ETH",
    "USDT",
    "BONK",
    "JUP",
    "RAY",
    "ORCA",
]

# Quote token voor base/quote prijzen
DEFAULT_QUOTE_TOKEN = "USDC"

# Poll interval in seconden (HF moet je zelf tunen t.o.v. latency / rate limits)
DEFAULT_POLL_INTERVAL_SEC = 2.0

# Volatility window (in seconden) en threshold (in %)
DEFAULT_VOL_WINDOW_SEC = 30.0
DEFAULT_VOL_THRESHOLD_PCT = 0.5
