
# jupiter_price.py

import requests
from typing import Dict, List, Optional
from .config import JUPITER_PRICE_URL


class JupiterPriceClient:
    """Kleine client voor Jupiter price API (on-chain aggregated)."""

    def __init__(self, base_url: str = JUPITER_PRICE_URL, timeout: float = 3.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def fetch_prices_usd(self, symbols: List[str]) -> Dict[str, float]:
        if not symbols:
            return {}
        ids_param = ",".join(sorted(set(sym.upper() for sym in symbols)))
        url = f"{self.base_url}?ids={ids_param}"
        resp = requests.get(url, timeout=self.timeout)
        resp.raise_for_status()
        data = resp.json()
        if "data" not in data:
            raise RuntimeError(f"Onverwachte Jupiter response: {data}")
        out: Dict[str, float] = {}
        for sym, info in data["data"].items():
            try:
                out[sym.upper()] = float(info["price"])
            except Exception:
                continue
        return out

    def get_pair_price(self, base: str, quote: str, prices_usd: Dict[str, float]) -> Optional[float]:
        b = base.upper()
        q = quote.upper()
        if b not in prices_usd or q not in prices_usd:
            return None
        quote_usd = prices_usd[q]
        if quote_usd == 0:
            return None
        return prices_usd[b] / quote_usd
